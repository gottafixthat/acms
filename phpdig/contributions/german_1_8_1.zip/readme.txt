------------------------------------------
Inhalt:
de-language.php -  in den Ordner \locales
common_words.txt - in den Ordner \includes
------------------------------------------
