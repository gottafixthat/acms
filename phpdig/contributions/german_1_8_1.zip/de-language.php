<?
/*
--------------------------------------------------------------------------------
PhpDig Version 1.8.x
This program is provided under the GNU/GPL license.
See the LICENSE file for more information.
All contributors are listed in the CREDITS file provided with this package.
PhpDig Website : http://www.phpdig.net/
--------------------------------------------------------------------------------
*/

// German language file from Gregor Mucha
// Version 2 from Matthias Strohmaier
// Version 3 from Roland Sippel - email: roland.sippel(at)epost.de
// Version 4 from Roland Sippel fuer Version 1.8.1
// deutsche gebraeuchliche W�rter erweitert
//
// common_words.txt beinhaltet jetzt deutsche stoppwoerter (der, aber, wenn,...)
// im include Ordner
//--------------------------------------
//'keyword' => 'translation'
$phpdig_mess = array (
'upd_sites'    =>'Update sites',
'upd2'         =>'Update Done',
'links_per'    =>'Links per',
'yes'          =>'ja',
'no'           =>'nein',
'delete'       =>'l&ouml;schen',
'reindex'      =>'Erneut indizieren',
'back'         =>'Zur&uuml;ck',
'files'        =>'Dateien',
'admin'        =>'Administration',
'warning'      =>'Achtung!',
'index_uri'    =>'Welche URI soll indiziert werden?',
'spider_depth' =>'Suchtiefe',
'spider_warn'  =>"Bitte sicherstellen, dass niemand sonst diese Seite indiziert.
Ein Sperr-Mechanismus wird in einer sp&auml;teren Version realisiert werden.",
'site_update'  =>"Update der Seite oder des Unterordners",
'clean'        =>'s&auml;ubern',
't_index'      =>"Index",
't_dic'        =>'W&ouml;rterbuch',
't_stopw'      =>'gebr&auml;uchliche W&ouml;rter',
't_dash'       =>'dashes',

'update'       =>'Update',
'exclude'      =>'Zweig ausschlie&szlig;en und l&ouml;schen',
'excludes'     =>'Ausgeschlossene Pfade',
'tree_found'   =>'Zweig gefunden',
'update_mess'  =>'Erneut indizieren oder Zweig l&ouml;schen?',
'update_warn'  =>"\"Ausschliessen\" l&ouml;scht alle indizierten Eintr&auml;ge.",
'update_help'  =>'Bitte auf das Kreuz klicken um den Zweig zu l&ouml;schen,
auf das gr&uuml;ne H&auml;kchen um den Zweig zu aktualisieren
oder auf das Minus-Zeichen um den Zweig auszuschlie&szlig;en.',
'branch_start' =>'Bitte den Ordner ausw&auml;hlen, der rechts angezeigt werden soll.',
'branch_help1' =>'Bitte Ordner f&uuml;r individuelles Update ausw&auml;hlen',
'branch_help2' =>'Bitte auf das Kreuz klicken um das Dokument zu l&ouml;schen,
aauf das gr&uuml;ne H�kchen um es erneut zu indizieren.',
'redepth'      =>'levels depth',
'branch_warn'  =>"Das L&ouml;schen ist endg&uuml;ltig",
'to_admin'     =>"zum Admin-Interface",
'to_update'    =>"zum Update-Interface",

'search'       =>'Suche',
'results'      =>'Ergebnisse',
'display'      =>'Anzeige',
'w_begin'      =>'Alle W&ouml;rter (UND)',
'w_whole'      =>'Exakter Wortlaut',
'w_part'       =>'irgendein Wort (ODER)',
'alt_try'      =>'Meinen Sie: ',

'limit_to'     =>'Suche begrenzen auf',
'this_path'    =>'oder nur diesen Pfad',
'total'        =>'Gesamtergebnisse',
'seconds'      =>'sekunden',
'w_common_sing'     =>'ist ein sehr gebr&auml;uchliches Wort und wird ignoriert.',
'w_short_sing'      =>'ist zu kurz und wird ignoriert.',
'w_common_plur'     =>'sind sehr gebr&auml;uchliche Worte und werden ignoriert.',
'w_short_plur'      =>'sind zu kurz und werden ignoriert.',
's_results'    =>'Ergebnisse',
'previous'     =>'Vorherige',
'next'         =>'N&auml;chste',
'on'           =>'f&uuml;r den Suchbegriff:',

'id_start'     =>'Seite indizieren',
'id_end'       =>'Indizierung abgeschlossen!',
'id_recent'    =>'Wurde gerade indiziert',
'num_words'    =>'Anzahl der Worte',
'time'         =>'Zeit',
'error'        =>'Fehler',
'no_spider'    =>'Spider nicht gestartet',
'no_site'      =>"Diese Seite ist nicht in der Datenbank",
'no_temp'      =>'Kein Link in der tempor&auml;reren Tabelle',
'no_toindex'   =>'Es ist nichts vorhanden, was indiziert werden k&ouml;nnte',
'double'       =>'Duplikat eines existierenden Dokuments',

'spidering'    =>'Der Spider arbeitet gerade...',
'links_more'   =>'mehr Links',
'level'        =>'Level',
'links_found'  =>'Links gefunden',
'define_ex'    =>'Ausgrenzungen definieren',
'index_all'    =>'Alles indizieren',

'end'          =>'Ende',
'no_query'     =>'Bitte Suchfeld ausf&uuml;llen',
'pwait'        =>'Bitte warten',
'statistics'   =>'Statistik',

// INSTALL
'slogan'   =>'The smallest search engine in the universe : version',
'installation'   =>'Installation',
'instructions' =>'Bitte hier die MySQL-Parameter eingeben. Der Benutzer muss Rechte f&uuml;r: Datenbank und Tabellen anlegen, Tabellen updates.',
'hostname'   =>'Hostname  :',
'port'   =>'Port (leer = Standard-Port) :',
'sock'   =>'Sock (leer = Standard-Sock) :',
'user'   =>'User :',
'password'   =>'Passwort :',
'phpdigdatabase'   =>'PhpDig Datenbank :',
'tablesprefix'   =>'Tabellen prefix :',
'instructions2'   =>'* optional. Kleinbuchstaben, 16 Zeichen max.',
'installdatabase'   =>'Installiere phpdig database',
'error1'   =>'Can\'t find connexion template. (Error 1)',
'error2'   =>'Can\'t write connexion template. (Error 2)',
'error3'   =>'Can\'t find init_db.sql file. (Error 3)',
'error4'   =>'Can\'t create tables. (Error 4)',
'error5'   =>'Can\'t find all config database files. (Error 3) ',
'error6'   =>'Can\'t create database.<br />Verify user\'s rights. (Error 6) ',
'error7'   =>'Can\'t connect to database<br />Verify connection datas. (Error 7)',
'createdb' =>'Erstellen Datenbank',
'createtables' =>'Erzeuge nur Tabellen',
'updatedb' =>'Update vorhandene Datenbank',
'existingdb' =>'Nur Zugangsparameter f&uuml;r MySQL aktualieseren',
// CLEANUP_ENGINE
'cleaningindex'   =>'S&auml;ubere Index',
'enginenotok'   =>' index references targeted an inexistent keyword.',
'engineok'   =>'Die Datenbank ist zusammenh�ngend sauber.',
// CLEANUP_KEYWORDS
'cleaningdictionnary'   =>'S&auml;ubere W&ouml;rterbuch',
'keywordsok'   =>'Alle Schl&uuml;sselw&ouml;rter sind in einer oder mehr Seiten.',
'keywordsnotok'   =>' Schl&uuml;sselw&ouml;rter die nicht mindestens in einer Seite sind.',
// CLEANUP_COMMON
'cleanupcommon' =>'S&auml;ubere h&auml;ufige W&ouml;rter',
'cleanuptotal' =>'Gesamt ',
'cleaned' =>' ges&auml;ubert.',
'deletedfor' =>' gel�scht f&uuml;r ',
// INDEX ADMIN
'digthis' =>'Dig this !',
'databasestatus' =>'Datenbank Status',
'entries' =>' Eintr&auml;ge ',
'updateform' =>'Update Form',
'deletesite' =>'Seite l&ouml;schen',
// SPIDER
'spiderresults' =>'Spider Ergebnisse',
// STATISTICS
'mostkeywords' =>'die meisten Schl&uuml;sselw&ouml;rter',
'richestpages' =>'die umfangreichsten Seiten',
'mostterms'    =>'h&auml;ufigsten Suchbegriffe',
'largestresults'=>'die meisten Treffer',
'mostempty'     =>'h&auml;ufigsten Suchbegriffe OHNE Treffer',
'lastqueries'   =>'die letzten Suchanfragen',
'responsebyhour'=>'Antwortzeiten nach Tageszeit',
// UPDATE
'userpasschanged' =>'Benutzer/Password ge&auml;ndert!',
'uri' =>'URI : ',
'change' =>'&Auml;ndern',
'root' =>'Root',
'pages' =>' Seiten',
'locked' => 'gesperrt',
'unlock' => 'Seite entsperren',
'onelock' => 'Eine Seite ist wegen Indexierung gesperrt. Die Aktion ist zur Zeit nicht m&ouml;glich.',
// PHPDIG_FORM
'go' =>'Go ...',
// SEARCH_FUNCTION
'noresults' =>'Keine Treffer in den Seiten gefunden.'
);
?>